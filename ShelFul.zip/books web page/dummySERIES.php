<!DOCTYPE html>
<html lang="en-US">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>	
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<link rel="stylesheet" type="text/css" href="CSS/dummySERIES.css">
<title title=""></title>
</head>

<body>
<?php
include('headr.html');
?>

<center id="seriesname">HARRY POTTER</center>
<center><a href=".html" id="seriesname" style="font-size:175%;margin-top:0px;text-decoration:none;">JK ROWLING</a></center>
<center><div id="abc">
	<div class="gall">
		<a href="davinci.html"><img src="pictures/davinci.jpg" alt="Trolltunga Norway"></a>
		<div class="desc">Add a description of the image here</div>
	</div>
	<div class="gall">
		<a href=".html"><img src="pictures/.jpg" alt="Trolltunga Norway"></a>
		<div class="desc">Add a description of the image here</div>
	</div>
	<div class="gall">
		<a href=".html"><img src="pictures/.jpg" alt="Trolltunga Norway"></a>
		<div class="desc">Add a description of the image here</div>
	</div>
	<div class="gall">
		<a href=".html"><img src="pictures/.jpg" alt="Trolltunga Norway"></a>
		<div class="desc">Add a description of the image here</div>
	</div>
	<div class="gall">
		<a href=".html"><img src="pictures/.jpg" alt="Trolltunga Norway"></a>
		<div class="desc">Add a description of the image here</div>
	</div>
	<div class="gall">
		<a href=".html"><img src="pictures/.jpg" alt="Trolltunga Norway"></a>
		<div class="desc">Add a description of the image here</div>
	</div>
	<div class="gall">
		<a href=".html"><img src="pictures/.jpg" alt="Trolltunga Norway"></a>
		<div class="desc">Add a description of the image here</div>
	</div>
	<div class="gall">
		<a href=".html"><img src="pictures/.jpg" alt="Trolltunga Norway"></a>
		<div class="desc">Add a description of the image here</div>
	</div>
	
</div></center>

<br><br><br><br><br>
<?php
include('footer.html');
?>

</body>
</html>