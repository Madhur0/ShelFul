<!DOCTYPE html>
<html lang="en-US">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>	
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<link rel="stylesheet" type="text/css" href="CSS/dummySERIES.css">
<title title="Heroes Of Olympus">Heroes Of Olympus</title>
</head>

<body>
<?php
include('headr.html');
?>

<center id="seriesname">HEROES OF OLYMPUS</center>
<center><a href="dummyauthor.php?AID=<?php echo '110'; ?>" id="seriesname" style="font-size:175%;margin-top:0px;text-decoration:none;">RICK RIORDAN</a></center>
<center><div id="abc">
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '82'; ?>"><img src="pictures/hoo1.jpg" alt="The Lost Hero"></a>
		<div class="desc"><strong>The Lost Hero</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '83'; ?>"><img src="pictures/hoo2.jpg" alt="The Sun of Neptune"></a>
		<div class="desc">The Sun of Neptune</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '84'; ?>"><img src="pictures/hoo3.jpg" alt="The Mark of Athena"></a>
		<div class="desc">The Mark of Athena</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '85'; ?>"><img src="pictures/hoo4.jpg" alt="The House of Hades"></a>
		<div class="desc">The House of Hades</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '86'; ?>"><img src="pictures/hoo5.jpg" alt="The Blood of Olympus"></a>
		<div class="desc">The Blood of Olympus</strong></div>
	</div>
</div></center>

<br><br><br><br><br>
<?php
include('footer.html');
?>

</body>
</html>