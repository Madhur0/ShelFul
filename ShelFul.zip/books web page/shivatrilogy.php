<!DOCTYPE html>
<html lang="en-US">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>	
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<link rel="stylesheet" type="text/css" href="CSS/dummySERIES.css">
<title title="Shiva Trilogy">Shiva Trilogy</title>
</head>

<body bgcolor="#FFE4C4">
<?php
	include('headr.html');
?>

<center id="seriesname">SHIVA TRILOGY</center>
<center><a href="dummyauthor.php?AID=<?php echo '102'; ?>" id="seriesname" style="font-size:175%;margin-top:0px;text-decoration:none;">AMISH TRIPATHI</a></center>
<center><div id="abc">
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '76'; ?>"><img src="pictures/shiva1.jpg" alt="The Immortals of Meluha"></a>
		<div class="desc"><strong>The Immortals of Meluha</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '77'; ?>"><img src="pictures/shiva2.jpg" alt="The Secret of the Nagas"></a>
		<div class="desc">The Secret of the Nagas</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '78'; ?>"><img src="pictures/shiva3.jpg" alt="The Oath of the Vayuputras"></a>
		<div class="desc">The Oath of the Vayuputras</strong></div>
	</div>
	
</div></center>

<br><br><br><br><br>
<?php
	include('footer.html');
?>

</body>

</html>