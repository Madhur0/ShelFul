<!DOCTYPE html>
<html lang="en-US">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>	
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<link rel="stylesheet" type="text/css" href="CSS/dummySERIES.css">
<title title="Harry Potter">Harry Potter</title>
</head>

<body bgcolor="#FFE4C4">
<?php
	include('headr.html');
?>


<center id="seriesname">HARRY POTTER</center>
<center><a href="dummyauthor.php?AID=<?php echo '106'; ?>" id="seriesname" style="font-size:175%;margin-top:0px;text-decoration:none;">JK ROWLING</a></center>
<center><div id="abc">
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '69'; ?>"><img src="pictures/hp1.jpg" alt="Harry Potter and the Philosopher's Stone"></a>
		<div class="desc"><strong>Harry Potter and the Philosopher's Stone</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '70'; ?>"><img src="pictures/hp2.jpg" alt="Harry Potter and the Chamber of Secrets"></a>
		<div class="desc">Harry Potter and the Chamber of Secrets</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '71'; ?>"><img src="pictures/hp3.jpg" alt="Harry Potter and the Prisoner of Azkaban"></a>
		<div class="desc">Harry Potter and the Prisoner of Azkaban</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '72'; ?>"><img src="pictures/hp4.jpg" alt="Harry Potter and the Goblet of Fire"></a>
		<div class="desc">Harry Potter and the Goblet of Fire</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '73'; ?>"><img src="pictures/hp5.jpg" alt="Harry Potter and the Order of Phoenix"></a>
		<div class="desc">Harry Potter and the Order of Phoenix</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '74'; ?>"><img src="pictures/hp6.jpg" alt="Harry Potter and the Half-Blood Prince"></a>
		<div class="desc">Harry Potter and the Half-Blood Prince</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '75'; ?>"><img src="pictures/hp7.jpg" alt="Harry Potter and the Deathly Hallows"></a>
		<div class="desc">Harry Potter and the Deathly Hallows</strong></div>
	</div>
</div></center>




<br><br><br><br><br>
<?php
	include('footer.html');
?>

</body>

</html>