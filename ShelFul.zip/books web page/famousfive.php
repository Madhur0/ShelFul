<!DOCTYPE html>
<html lang="en-US">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>	
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<link rel="stylesheet" type="text/css" href="CSS/dummySERIES.css">
<title title="Famous Five">Famous Five</title>
</head>

<body bgcolor="#FFE4C4">
<?php
	include('headr.html');
?>

<center id="seriesname">FAMOUS FIVE</center>
<center><a href="enidblyton.html" id="seriesname" style="font-size:175%;margin-top:0px;text-decoration:none;">ENID BLYTON</a></center>
<center><div id="abc">
	<div class="gall">
		<a href="ff1.html"><img src="pictures/ff1.jpg" alt="Five On a Treasure Island"></a>
		<div class="desc">Five On a Treasure Island</div>
	</div>
	<div class="gall">
		<a href="ff2.html"><img src="pictures/ff2.jpg" alt="Five Go Adventuring Again"></a>
		<div class="desc">Five Go Adventuring Again</div>
	</div>
	<div class="gall">
		<a href="ff3.html"><img src="pictures/ff3.jpg" alt="Five Run Away Together"></a>
		<div class="desc">Five Run Away Together</div>
	</div>
	<div class="gall">
		<a href="ff4.html"><img src="pictures/ff4.jpg" alt="Five Go to Smugglers"></a>
		<div class="desc">Five Go to Smugglers</div>
	</div>
	<div class="gall">
		<a href="ff5.html"><img src="pictures/ff5.jpg" alt="Five Go off in a Caravan"></a>
		<div class="desc">Five Go off in a Caravan</div>
	</div>
	<div class="gall">
		<a href="ff6.html"><img src="pictures/ff6.jpg" alt="Five On Kirrin Island Again"></a>
		<div class="desc">Five On Kirrin Island Again</div>
	</div>
	<div class="gall">
		<a href="ff7.html"><img src="pictures/ff7.jpg" alt="Five Go off to Camp"></a>
		<div class="desc">Five Go off to Camp</div>
	</div>
	<div class="gall">
		<a href="ff8.html"><img src="pictures/ff8.jpg" alt="Five Get into Trouble"></a>
		<div class="desc">Five Get into Trouble</div>
	</div>
	<div class="gall">
		<a href="ff9.html"><img src="pictures/ff9.jpg" alt="Five Fall into Adventure"></a>
		<div class="desc">Five Fall into Adventure</div>
	</div>
	<div class="gall">
		<a href="ff10.html"><img src="pictures/ff10.jpg" alt="Five On a Hike Together"></a>
		<div class="desc">Five On a Hike Together</div>
	</div>
	<div class="gall">
		<a href="ff11.html"><img src="pictures/ff11.jpg" alt="Five Have a Wonderful Time"></a>
		<div class="desc">Five Have a Wonderful Time</div>
	</div>
	<div class="gall">
		<a href="ff12.html"><img src="pictures/ff12.jpg" alt="Five Go Down to The Sea"></a>
		<div class="desc">Five Go Down to The Sea</div>
	</div>
	<div class="gall">
		<a href="ff13.html"><img src="pictures/ff13.jpg" alt="Five Go to Mystery Moor"></a>
		<div class="desc">Five Go to Mystery Moor</div>
	</div>
	<div class="gall">
		<a href="ff14.html"><img src="pictures/ff14.jpg" alt="Five Have Plenty of Fun"></a>
		<div class="desc">Five Have Plenty of Fun</div>
	</div>
	<div class="gall">
		<a href="ff15.html"><img src="pictures/ff15.jpg" alt="Five On a Secret Trail"></a>
		<div class="desc">Five On a Secret Trail</div>
	</div>
	<div class="gall">
		<a href="ff16.html"><img src="pictures/ff16.jpg" alt="Five Go to Billycock Hill"></a>
		<div class="desc">Five Go to Billycock Hill</div>
	</div>
	<div class="gall">
		<a href="ff17.html"><img src="pictures/ff17.jpg" alt="Five Get into a Fix"></a>
		<div class="desc">Five Get into a Fix</div>
	</div>
	<div class="gall">
		<a href="ff18.html"><img src="pictures/ff18.jpg" alt="Five On Finniston Farm"></a>
		<div class="desc">Five On Finniston Farm</div>
	</div>
	<div class="gall">
		<a href="ff19.html"><img src="pictures/ff19.jpg" alt="Five Go to Demons Rocks"></a>
		<div class="desc">Five Go to Demons Rocks</div>
	</div>
	<div class="gall">
		<a href="ff20.html"><img src="pictures/ff20.jpg" alt="Five Have a Mystery to Solve"></a>
		<div class="desc">Five Have a Mystery to Solve</div>
	</div>
	<div class="gall">
		<a href="ff21.html"><img src="pictures/ff21.jpg" alt="Five Are Together Again"></a>
		<div class="desc">Five Are Together Again</div>
	</div>
</div></center>




<br><br><br><br><br>
<?php
	include('footer.html');
?>

</body>

</html>