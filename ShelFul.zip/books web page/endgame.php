<!DOCTYPE html>
<html lang="en-US">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>	
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<link rel="stylesheet" type="text/css" href="CSS/dummySERIES.css">
<title title="End Game">End Game</title>
</head>

<body bgcolor="#FFE4C4">
<?php
	include('headr.html');
?>


<center id="seriesname">END GAME</center>
<center><a href="dummyauthor.php?AID=<?php echo '116'; ?>" id="seriesname" style="font-size:175%;margin-top:0px;text-decoration:none;">JAMES FREY</a></center>
<center><div id="abc">
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '79'; ?>"><img src="pictures/eg1.jpg" alt="The Calling"></a>
		<div class="desc"><strong>The Calling</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '80'; ?>"><img src="pictures/eg2.jpg" alt="Sky Key"></a>
		<div class="desc">Sky Key</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '81'; ?>"><img src="pictures/eg3.jpg" alt="Rules Of The Game"></a>
		<div class="desc">Rules Of The Game</strong></div>
	</div>
</div></center>


<br><br><br><br><br>
<?php
	include('footer.html');
?>

</body>

</html>