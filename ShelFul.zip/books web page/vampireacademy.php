<!DOCTYPE html>
<html lang="en-US">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>	
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<link rel="stylesheet" type="text/css" href="CSS/dummySERIES.css">
<title title="Vampire Academy">Vampire Academy</title>
</head>

<body bgcolor="#FFE4C4">
<?php
	include('headr.html');
?>

<center id="seriesname">VAMPIRE ACADEMY</center>
<center><a href="dummyauthor.php?AID=<?php echo '115'; ?>" id="seriesname" style="font-size:175%;margin-top:0px;text-decoration:none;">RICHELLE MEAD</a></center>
<center><div id="abc">
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '97'; ?>"><img src="pictures/VA1.jpg" alt="Vampire Academy"></a>
		<div class="desc"><strong>Vampire <br>Academy</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '98'; ?>"><img src="pictures/VA2.jpg" alt="Vampire Academy-Frostbite"></a>
		<div class="desc">Vampire Academy- Frostbite</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '99'; ?>"><img src="pictures/VA3.jpg" alt="Vampire Academy-Shadow Kiss"></a>
		<div class="desc">Vampire Academy- Shadow Kiss</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '100'; ?>"><img src="pictures/VA4.jpg" alt="Vampire Academy-Blood Promise"></a>
		<div class="desc">Vampire Academy- Blood Promise</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '101'; ?>"><img src="pictures/VA5.jpg" alt="Vampire Academy-Spirit Bound"></a>
		<div class="desc">Vampire Academy- Spirit Bound</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '102'; ?>"><img src="pictures/VA6.jpg" alt="Vampire Academy-Last Sacrifice"></a>
		<div class="desc">Vampire Academy- Last Sacrifice</strong></div>
	</div>
	
</div></center>

<br><br><br><br><br>
<?php
	include('footer.html');
?>

</body>

</html>