<!DOCTYPE html>
<html lang="en-US">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>	
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<link rel="stylesheet" type="text/css" href="CSS/dummySERIES.css">
<title title="Assassin's Creed">Assassin's Creed</title>
</head>

<body>

<body bgcolor="#FFE4C4">
<?php
	include('headr.html');
?>

<center id="seriesname">ASSASSIN'S CREED</center>
<center><a href="dummyauthor.php?AID=<?php echo '114'; ?>" id="seriesname" style="font-size:175%;margin-top:0px;text-decoration:none;">Oliver Bowden</a></center>
<center><div id="abc">
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '61'; ?>"><img src="pictures/assassin1.jpg" alt="Renaissance"></a>
		<div class="desc"><strong>Renaissance</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '62'; ?>"><img src="pictures/assassin2.jpg" alt="Brotherhood"></a>
		<div class="desc">Brotherhood</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '63'; ?>"><img src="pictures/assassin3.jpg" alt="The Secret Crusade"></a>
		<div class="desc">The Secret Crusade</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '64'; ?>"><img src="pictures/assassin4.jpg" alt="Relevations"></a>
		<div class="desc">Relevations</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '65'; ?>"><img src="pictures/assassin5.jpg" alt="Forsaken"></a>
		<div class="desc">Forsaken</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '66'; ?>"><img src="pictures/assassin6.jpg" alt="Black Flag"></a>
		<div class="desc">Black Flag</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '67'; ?>"><img src="pictures/assassin7.jpg" alt="Unity"></a>
		<div class="desc">Unity</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '68'; ?>"><img src="pictures/assassin8.jpg" alt="Underworld"></a>
		<div class="desc">Underworld</strong></div>
	</div>
</div></center>


<br><br><br><br><br>
<?php
	include('footer.html');
?>


</body>

</html>