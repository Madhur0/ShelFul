<!DOCTYPE html>
<html lang="en-US">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>	
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<link rel="stylesheet" type="text/css" href="CSS/dummySERIES.css">
<title title="Alex Rider">Alex Rider</title>
</head>

<body>

<body bgcolor="#FFE4C4">
<?php
	include('headr.html');
?>


<center id="seriesname">ALEX RIDER</center>
<center><a href="dummyauthor.php?AID=<?php echo '117'; ?>" id="seriesname" style="font-size:175%;malexridergin-top:0px;text-decoration:none;">Anthony Horowitz</a></center>
<center><div id="abc">
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '39'; ?>"><img src="pictures/alexrider1.jpg" alt="Stormbreaker"></a>
		<div class="desc"><strong>Stormbreaker</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '40'; ?>"><img src="pictures/alexrider2.jpg" alt="Point Blank"></a>
		<div class="desc">Point Blank</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '41'; ?>"><img src="pictures/alexrider3.jpg" alt="Skeleton Key"></a>
		<div class="desc">Skeleton Key</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '42'; ?>"><img src="pictures/alexrider4.jpg" alt="Eagle Strike"></a>
		<div class="desc">Eagle Strike</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '43'; ?>"><img src="pictures/alexrider5.jpg" alt="Scorpia"></a>
		<div class="desc">Scorpia</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '44'; ?>"><img src="pictures/alexrider6.jpg" alt="Ark Angel"></a>
		<div class="desc">Ark Angel</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '45'; ?>"><img src="pictures/alexrider7.jpg" alt="Snakehead"></a>
		<div class="desc">Snakehead</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '46'; ?>"><img src="pictures/alexrider8.jpg" alt="Crocodile Tears"></a>
		<div class="desc" style="font-size:15px;">Crocodile Tealexriders</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '47'; ?>"><img src="pictures/alexrider9.jpg" alt="Scorpia Rising"></a>
		<div class="desc">Scorpia Rising</strong></div>
	</div>
</div></center>


<br><br><br><br><br>
<?php
	include('footer.html');
?>


</body>

</html>