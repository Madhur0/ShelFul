<!DOCTYPE html>
<html lang="en-US">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>	
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<link rel="stylesheet" type="text/css" href="CSS/dummySERIES.css">
<title title="Robert Langdon Series">Robert Langdon Series</title>
</head>

<body bgcolor="#FFE4C4">
<?php
	include('headr.html');
?>


<center id="seriesname">ROBERT LANGDON SERIES</center>
<center><a href="dummyauthor.php?AID=<?php echo '105'; ?>" id="seriesname" style="font-size:175%;margin-top:0px;text-decoration:none;">DAN BROWN</a></center>
<center><div id="abc">
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo ''; ?>"><img src="pictures/angels.jpg" alt="Angels and Demons"></a>
		<div class="desc">Angels and Demons</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo ''; ?>"><img src="pictures/davinci.jpg" alt="The Da Vinci Code"></a>
		<div class="desc">The Da Vinci Code</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo ''; ?>"><img src="pictures/symbol.jpg" alt="The Lost Symbol"></a>
		<div class="desc">The Lost Symbol</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo ''; ?>"><img src="pictures/inferno.jpg" alt="Inferno"></a>
		<div class="desc">Inferno</div>
	</div>
</div></center>

<br><br><br><br><br>
<?php
	include('footer.html');
?>

</body>

</html>