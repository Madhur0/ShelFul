<!DOCTYPE html>
<html lang="en-US">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>	
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<link rel="stylesheet" type="text/css" href="CSS/dummySERIES.css">
<title title="PERCY JACKSON">PERCY JACKSON</title>
</head>

<body bgcolor="#FFE4C4">
<?php
	include('headr.html');
?>


<center id="seriesname">PERCY JACKSON</center>
<center><a href="dummyauthor.php?AID=<?php echo '110'; ?>" id="seriesname" style="font-size:175%;margin-top:0px;text-decoration:none;">RICK RIORDAN</a></center>
<center><div id="abc">
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '55'; ?>"><img src="pictures/Percy1.jpg" alt="Percy Jackson-The Lightning Thief"></a>
		<div class="desc"><strong>Percy Jackson-The Lightning Thief</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '56'; ?>"><img src="pictures/Percy2.jpg" alt="Percy Jackson-The Sea of Monsters"></a>
		<div class="desc">Percy Jackson-The Sea of Monsters</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '57'; ?>"><img src="pictures/Percy3.jpg" alt="Percy Jackson-The Titan's Curse"></a>
		<div class="desc">Percy Jackson-The Titan's Curse</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '58'; ?>"><img src="pictures/Percy4.jpg" alt="Percy Jackson-The Battle of the Labyrinth"></a>
		<div class="desc">Percy Jackson-The Battle of Labyrinth</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '59'; ?>"><img src="pictures/Percy5.jpg" alt="Percy Jackson-The Last Olympian"></a>
		<div class="desc">Percy Jackson-The Last Olympian</div>
	</div>
	
</div></center>

<br><br><br><br><br>
<?php
	include('footer.html');
?>

</body>

</html>