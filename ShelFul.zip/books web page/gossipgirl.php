<!DOCTYPE html>
<html lang="en-US">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>	
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico"/>
<link rel="stylesheet" type="text/css" href="CSS/dummySERIES.css">
<title title="Gossip Girl">Gossip Girl</title>
</head>

<body>
<?php
include('headr.html');
?>

<center id="seriesname">Gossip Girl</center>
<center><a href="dummyauthor.php?AID=<?php echo '119'; ?>" id="seriesname" style="font-size:175%;margin-top:0px;text-decoration:none;">Cecily von Ziegesar</a></center>
<center><div id="abc">
	<div class="gall">
		<a href="#"><img src="pictures/gg1.jpg" alt="Psycho Killer"></a>
		<div class="desc"><strong>Psycho Killer</strong><br>Available Soon</div>
	</div>
	<div class="gall">
		<a href="#"><img src="pictures/gg2.jpg" alt="You Know You Love Me"></a>
		<div class="desc"><strong  style="font-size:14px;">You Know You Love Me</strong><br>Available Soon</div>
	</div>
	<div class="gall">
		<a href="#"><img src="pictures/gg3.jpg" alt="All I Want is Everything"></a>
		<div class="desc"><strong  style="font-size:14px;">All I Want is Everything</strong><br>Available Soon</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '103'; ?>"><img src="pictures/gg4.jpg" alt="Because I'm Worth It"></a>
		<div class="desc"><strong>Because I'm <br>Worth It</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '104'; ?>"><img src="pictures/gg5.jpg" alt="I Like It Like That"></a>
		<div class="desc">I Like It <br>Like That</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '105'; ?>"><img src="pictures/gg6.jpg" alt="You are the one that I want"></a>
		<div class="desc">You're the one that I want</div>
	</div>
	<div class="gall">
		<a href="dummybook.php?PID=<?php echo '106'; ?>"><img src="pictures/gg7.jpg" alt="Nobody Does It Better"></a>
		<div class="desc">Nobody Does It Better</div>
	</div>
	<div class="gall">
		<a href="#"><img src="pictures/gg8.jpg" alt="Only in Your Dreams"></a>
		<div class="desc">Only in Your Dreams</strong><br>Available Soon</div>
	</div>
	
</div></center>

<br><br><br><br><br>
<?php
include('footer.html');
?>

</body>
</html>