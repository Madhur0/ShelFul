<!DOCTYPE html>
<html lang="en-US">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/x-icon" href="../favicon.ico">
<title>ABOUT US</title>
<link rel="stylesheet" type="text/css" href="../mystyle.css"> 
<script src="../jquery.js"></script>
<script src="../navfix.js">
</script> 			
</head>

<body bgcolor="#FFE4C4">
<?php
	include('headr.html');
?>

<div>
<center>
<div style="border:2px solid lightgrey; border-radius: 20px; margin: 80px 250px 80px 250px; background-color:#f8f8f8;">
<p style="font-family:calibri; font-size:50px; color:grey; margin: 10px 0 0px 0;"><strong>ABOUT US</strong></p>
<div style="font-family:calibri; font-size:19px; color:grey;"><b>Why to be a bookaholic</b></div>
<br><p style="font-family:calibri; font-size:19px; color:grey;margin:40px;">Shelful is a user friendly initiative by two amateur web developers <u>Madhur Mittal</u> and <u>Pragya Nagpal</u>, currently pursuing Bachelor's degree in Engineering. 
We, through our website, aspire to provide easy access to all popular and latest novels (fiction) for all the bookaholics. 
The website is easy to access and provides a large variety of books to choose from.
<center style="font-family:calibri; font-size:19px; color:grey;margin:40px;">Happy Reading! :)</center></p>
<br><br><br><br><br>
</div></center>
</div>

<?php
	include('footer.html');
?>

</body>
</html>